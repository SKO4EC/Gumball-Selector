import random
from sys import exit

Season_6 = random.randint(1,44)

print("S6E{Season_6}".format(**locals()))
exit()