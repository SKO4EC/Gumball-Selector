import random
from sys import exit

Season_2to5 = random.randint(1,40)
Season_choice = random.randint(2,5)
print("S{Season_choice}E{Season_2to5}".format(**locals()))
exit()