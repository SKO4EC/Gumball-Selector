import random

Season = random.randint(1,6)
if(Season == 1):
    import Seasons.Season_1
if(Season == 2):
    import Seasons.Season_2to5
if(Season == 3):
    import Seasons.Season_2to5
if(Season == 4):
    import Seasons.Season_2to5
if(Season == 5):
    import Seasons.Season_2to5
if(Season == 6):
    import Seasons.Season_6